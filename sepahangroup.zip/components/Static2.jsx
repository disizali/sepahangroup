import React, { Component } from "react";

export class Static2 extends Component {
  render() {
    return (
      <section className="static2">
        <polygon />
      </section>
    );
  }
}

export default Static2;
