import React, { Component } from "react";

export class Image extends Component {
  render() {
    return <img src="/images/banner.png" width="100%" />;
  }
}

export default Image;
