import axios from "axios";
import * as config from "./config";
const { API } = config;

export const login = async data => {
  const { data: result } = await axios.post(`${API}/auth`, data);
  return result;
};

export const getPosts = async () => {
  const { data: posts } = await axios.get(`${API}/posts`);
  return posts;
};
export const sendPost = async data => {
  const { data: post } = await axios.post(`${API}/posts`, data);
  return post;
};
export const deletePost = async data => {
  const { data: result } = await axios.delete(`${API}/posts`, { data });
  return result;
};
export const updatePost = async data => {
  const { data: result } = await axios.put(`${API}/posts`, data);
  return result;
};

export const getProducts = async () => {
  const { data: posts } = await axios.get(`${API}/products`);
  return posts;
};
export const sendProduct = async data => {
  const { data: product } = await axios.post(`${API}/products`, data);
  return product;
};
export const sendType = async data => {
  const { data: type } = await axios.post(`${API}/types`, data);
  return type;
};