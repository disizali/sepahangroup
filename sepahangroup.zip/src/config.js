export const HOST = "http://localhost:3000";
export const API = "http://localhost:3000/api";