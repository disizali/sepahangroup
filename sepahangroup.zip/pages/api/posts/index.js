import express from "express";
import path from "path";
const app = express();
import { sequelize as db } from "../../../models";
const { Post } = db.models;

app
  .route("/api/posts")
  .get(async (req, res) => {
    const posts = await Post.findAll({ order: [["id", "DESC"]] });
    res.send(posts);
  })
  .post(async (req, res) => {
    const { title, body, image } = req.body;
    const fileName = path.basename(image);
    if (!title || !body || !image) {
      return res.send("failed");
    }
    return res.send(await Post.create({ ...req.body, image: fileName }));
  })
  .delete(async (req, res) => {
    const { id } = req.body;
    if (!id) return res.send("failed1");
    const result = await Post.destroy({ where: { id } });
    res.send(result ? "deleted" : "failed2");
  })
  .put(async (req, res) => {
    const { title, body, image, id } = req.body;
    if (!title || !body || !image || !id) return res.send("failed");
    const result = await Post.update(req.body, { where: { id } });
    res.send(result ? "deleted" : "failed");
  });
export default app;
